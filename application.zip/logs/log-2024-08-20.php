<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
 ERROR - 2024-08-20 18:29:57 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:30:06 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:32:47 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:32:50 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:33:13 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:33:17 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:34:40 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:34:52 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:45:27 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:45:50 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:45:54 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:46:03 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:46:48 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:47:05 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:47:09 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:47:13 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:50:50 --> 404 Page Not Found: /index
ERROR - 2024-08-20 18:51:08 --> 404 Page Not Found: /index
ERROR - 2024-08-20 19:00:59 --> 404 Page Not Found: /index
ERROR - 2024-08-20 19:44:22 --> 404 Page Not Found: /index
ERROR - 2024-08-20 19:58:07 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:05:22 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:09:00 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:09:04 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:09:14 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:10:19 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:13:03 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:13:06 --> Query error: Unknown column 'awaiting_doc_verification' in 'where clause' - Invalid query: SELECT *
FROM `tblclient_survey_statuses`
WHERE `customer_id` = '7'
AND `user_id` = '1'
AND `awaiting_doc_verification` = 1
ERROR - 2024-08-20 20:14:20 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:46:15 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:46:16 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:47:03 --> Severity: error --> Exception: Too few arguments to function Clients::survey_update_ajax(), 0 passed in C:\wamp64\www\perfex\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\wamp64\www\perfex\application\controllers\admin\Clients.php 1135
ERROR - 2024-08-20 20:49:57 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:50:09 --> Severity: error --> Exception: Too few arguments to function Clients::survey_update_ajax(), 0 passed in C:\wamp64\www\perfex\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\wamp64\www\perfex\application\controllers\admin\Clients.php 1135
ERROR - 2024-08-20 20:57:32 --> 404 Page Not Found: /index
ERROR - 2024-08-20 20:57:42 --> Query error: Table 'perfex2.tblcustomer_survey_statuses' doesn't exist - Invalid query: SELECT *
FROM `tblcustomer_survey_statuses`
WHERE `customer_id` = '7'
AND `status_type` = 'Awaiting Installation'
ERROR - 2024-08-20 21:02:50 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:02:56 --> Query error: Table 'perfex2.tblcustomer_survey_statuses' doesn't exist - Invalid query: SELECT *
FROM `tblcustomer_survey_statuses`
WHERE `customer_id` = '7'
AND `status_type` = 'awaiting_dwp'
ERROR - 2024-08-20 21:05:35 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:05:54 --> Query error: Table 'perfex2.tblcustomer_survey_statuses' doesn't exist - Invalid query: SELECT *
FROM `tblcustomer_survey_statuses`
WHERE `customer_id` = '7'
AND `status_type` = 'awaiting_doc_verification'
ERROR - 2024-08-20 21:07:26 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:08:39 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:08:53 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:09:56 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:10:05 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:11:44 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:12:26 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:12:31 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:12:35 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:12:40 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:12:46 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:12:48 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:12:57 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:24:28 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:25:05 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:25:17 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:25:34 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:25:37 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:25:41 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:26:11 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:26:25 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:26:43 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:29:10 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:29:11 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:30:01 --> Severity: error --> Exception: Call to undefined function get_workflows_by_customer_id() C:\wamp64\www\perfex\application\views\admin\clients\groups\profile.php 366
ERROR - 2024-08-20 21:30:01 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:31:35 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:33:22 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:33:27 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:33:30 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:33:52 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:33:55 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:34:20 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:34:32 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:51:25 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:51:32 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:51:39 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:51:41 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:52:10 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:52:11 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:52:12 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:52:13 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:52:13 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:53:05 --> Severity: Warning --> Undefined variable $worflow_statuses C:\wamp64\www\perfex\application\views\admin\clients\groups\profile.php 367
ERROR - 2024-08-20 21:53:06 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:53:41 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:55:25 --> Severity: Warning --> Undefined variable $worflow_statuses C:\wamp64\www\perfex\application\views\admin\clients\groups\profile.php 378
ERROR - 2024-08-20 21:55:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\wamp64\www\perfex\application\views\admin\clients\groups\profile.php 378
ERROR - 2024-08-20 21:55:25 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:56:15 --> Severity: Warning --> Array to string conversion C:\wamp64\www\perfex\application\views\admin\clients\groups\profile.php 378
ERROR - 2024-08-20 21:56:15 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:56:59 --> Severity: Warning --> Array to string conversion C:\wamp64\www\perfex\application\views\admin\clients\groups\profile.php 378
ERROR - 2024-08-20 21:56:59 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:57:01 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:58:10 --> 404 Page Not Found: /index
ERROR - 2024-08-20 21:58:17 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:01:32 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:02:00 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:34:35 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:38:14 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:38:39 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:41:36 --> Severity: error --> Exception: Call to undefined function get_dwps_by_customer_id() C:\wamp64\www\perfex\application\views\admin\clients\groups\profile.php 478
ERROR - 2024-08-20 22:41:36 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:42:05 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:43:02 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:44:07 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:46:54 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:47:40 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:48:04 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:48:35 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:50:38 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:54:55 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:55:02 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:55:10 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:55:56 --> 404 Page Not Found: /index
ERROR - 2024-08-20 22:59:55 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:01:04 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:01:08 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:07:58 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:09:10 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:09:27 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:09:35 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:10:16 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:16:14 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:21:41 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:21:47 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:21:54 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:22:01 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:22:08 --> 404 Page Not Found: /index
ERROR - 2024-08-20 23:22:15 --> 404 Page Not Found: /index
